// API_KEY = "88d19dc158ea7364cddf833776d828a9";
// QUERY_BASE_URL = "https://api.themoviedb.org/3/search/movie?api_key=$API_KEY&query=Jack+Reacher";
// DETAILS_BASE_URL = "https://api.themoviedb.org/3/movie/157336?api_key=$API_KEY&append_to_response=videos";
// DETAILS_BASE_URL = "https://api.themoviedb.org/3/movie/157336/credits?api_key=$API_KEY";
// IMAGES_BASE_URL = "https://image.tmdb.org/t/p/w500";


// API_KEY = "a6c7723d";
// QUERY_BASE_URL = "http://www.omdbapi.com/?i=tt0063582&apikey=a6c7723d";
// DETAILS_BASE_URL = "https://api.themoviedb.org/3/movie/157336?api_key={api_key}&append_to_response=videos";
// IMAGES_BASE_URL = "https://image.tmdb.org/t/p/w500";