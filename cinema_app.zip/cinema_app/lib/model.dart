final List<Movie> movies = [
  Movie(
    name: "Venom",
    description: """
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo""",
    image: "assets/images/first.png",
    rating: 6.8,
    geners: ["Thriller", "Science Fiction", "Action"],
    stars: [
      {"Trevante Rhodes": "w5mqvAJ4FQAO5iZbO5Q5vv0MJ5s.jpg"},
      {"Ashton Sanders": "eONLhaBvc3IyhWsfwdIdbRnbK9M.jpg"},
      {"Alex Hibbert": "rWUu41SSz4bTiphToue2BrAlqZv.jpg"},
      {"André Holland": "nq6qk6P5idimcSJ0bpFqLQrb0Li.jpg"},
      {"Naomie Harris": "41TVAcYqKKF7PGf3x7QfaLvkLSW.jpg"},
      {"Mahershala Ali": "waUvfhRSpVe4vk0hGVcsr0dhpK6.jpg"},
      {"Janelle Monáe": "xavjGiGltQEDWqNdbe0zd1lO0UR.jpg"},
    ],
    duration: 112,
  ),
  Movie(
    name: "Alien Covenant",
    description: """
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo""",
    image: "assets/images/second.png",
    rating: 4.8,
    geners: ["Thriller", "Science Fiction"],
    stars: [
      {"Trevante Rhodes": "w5mqvAJ4FQAO5iZbO5Q5vv0MJ5s.jpg"},
      {"Ashton Sanders": "eONLhaBvc3IyhWsfwdIdbRnbK9M.jpg"},
      {"Alex Hibbert": "rWUu41SSz4bTiphToue2BrAlqZv.jpg"},
      {"André Holland": "nq6qk6P5idimcSJ0bpFqLQrb0Li.jpg"},
      {"Naomie Harris": "41TVAcYqKKF7PGf3x7QfaLvkLSW.jpg"},
      {"Mahershala Ali": "waUvfhRSpVe4vk0hGVcsr0dhpK6.jpg"},
      {"Janelle Monáe": "xavjGiGltQEDWqNdbe0zd1lO0UR.jpg"},
    ],
    duration: 110,
  ),
  Movie(
    name: "Moonlight",
    description: """
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo""",
    image: "assets/images/third.png",
    rating: 9.8,
    geners: ["Thriller", "Science Fiction"],
    stars: [
      {"Trevante Rhodes": "w5mqvAJ4FQAO5iZbO5Q5vv0MJ5s.jpg"},
      {"Ashton Sanders": "eONLhaBvc3IyhWsfwdIdbRnbK9M.jpg"},
      {"Alex Hibbert": "rWUu41SSz4bTiphToue2BrAlqZv.jpg"},
      {"André Holland": "nq6qk6P5idimcSJ0bpFqLQrb0Li.jpg"},
      {"Naomie Harris": "41TVAcYqKKF7PGf3x7QfaLvkLSW.jpg"},
      {"Mahershala Ali": "waUvfhRSpVe4vk0hGVcsr0dhpK6.jpg"},
      {"Janelle Monáe": "xavjGiGltQEDWqNdbe0zd1lO0UR.jpg"},
    ],
    duration: 111,
    trailer: "https://trailers.apple.com/movies/a24/moonlight/moonlight-trailer-1_h480p.mov",
  ),
  Movie(
    name: "Fury",
    description: """
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo""",
    image: "assets/images/forth.png",
    rating: 3.8,
    geners: ["Thriller", "Science Fiction"],
    stars: [
      {"Trevante Rhodes": "w5mqvAJ4FQAO5iZbO5Q5vv0MJ5s.jpg"},
      {"Ashton Sanders": "eONLhaBvc3IyhWsfwdIdbRnbK9M.jpg"},
      {"Alex Hibbert": "rWUu41SSz4bTiphToue2BrAlqZv.jpg"},
      {"André Holland": "nq6qk6P5idimcSJ0bpFqLQrb0Li.jpg"},
      {"Naomie Harris": "41TVAcYqKKF7PGf3x7QfaLvkLSW.jpg"},
      {"Mahershala Ali": "waUvfhRSpVe4vk0hGVcsr0dhpK6.jpg"},
      {"Janelle Monáe": "xavjGiGltQEDWqNdbe0zd1lO0UR.jpg"},
    ],
    duration: 100,
  ),
];

class Movie {
  final String name;
  final String description;
  final String image;
  final double rating;
  final int duration;
  final String trailer;
  final List<String> geners;
  final List<Map<String, String>> stars;

  Movie({
    this.name,
    this.description,
    this.image,
    this.rating,
    this.duration,
    this.trailer,
    this.geners,
    this.stars,
  });
}
