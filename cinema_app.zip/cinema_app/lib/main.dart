import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'model.dart';
import 'details.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Cinema App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // home: MyHomePage(),
      home: Details(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1F1F1),
      // appBar: AppBar(
      //   backgroundColor: Colors.transparent,
      //   elevation: 0.0,
      // ),
      body: Stack(
        alignment: Alignment.topCenter,
        children: <Widget>[
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(movies[index].image),
                fit: BoxFit.cover,
              ),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
              child: new Container(
                decoration: new BoxDecoration(color: Colors.white.withOpacity(0.0)),
              ),
            ),
          ),
          Positioned(
            bottom: 20.0,
            child: Container(
              width: 350,
              height: MediaQuery.of(context).size.height / 1.8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: Colors.white,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  SizedBox(height: 120.0),
                  Text(
                    movies[index].name,
                    style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      SmoothStarRating(
                        rating: movies[index].rating / 2,
                        color: Color(0xFFFECD4D),
                        borderColor: Colors.grey[300],
                      ),
                      SizedBox(width: 10.0),
                      Text(
                        "${movies[index].rating}",
                        style: TextStyle(color: Colors.yellow[600], fontSize: 20.0),
                      ),
                    ],
                  ),
                  SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(Icons.watch_later, color: Colors.grey[700]),
                      SizedBox(width: 5.0),
                      Text("${movies[index].duration} min", style: TextStyle(color: Colors.grey[800])),
                      SizedBox(width: 25.0),
                      Icon(Icons.date_range, color: Colors.grey[700]),
                      SizedBox(width: 5.0),
                      Text("Mar 23, 2019", style: TextStyle(color: Colors.grey[800])),
                    ],
                  ),
                  SizedBox(height: 10),
                  Wrap(
                    spacing: 15.0,
                    children: movies[index]
                        .geners
                        .map(
                          (item) => Chip(
                                label: Text(
                                  item,
                                  style: TextStyle(color: Colors.white),
                                ),
                                backgroundColor: Colors.green[400],
                              ),
                        )
                        .toList(),
                  ),
                  Container(
                    height: 80,
                    margin: EdgeInsets.symmetric(horizontal: 10.0),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: movies[index].stars.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          width: 50,
                          height: 50,
                          margin: EdgeInsets.symmetric(horizontal: 8.0),
                          decoration: ShapeDecoration(
                            shape: CircleBorder(),
                            image: DecorationImage(
                              image: CachedNetworkImageProvider(
                                "https://image.tmdb.org/t/p/w500/" + movies[0].stars[index].values.elementAt(0),
                                // fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.keyboard_arrow_down),
                  ),
                ],
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20.0),
            height: MediaQuery.of(context).size.height / 1.7,
            child: Swiper(
              onIndexChanged: (idx) {
                setState(() {
                  index = idx;
                });
              },
              // layout: SwiperLayout.CUSTOM,
              // customLayoutOption: new CustomLayoutOption(startIndex: -1, stateCount: 3)
              //     .addTranslate([new Offset(-370.0, -40.0), new Offset(0.0, 0.0), new Offset(370.0, -40.0)]),
              // itemWidth: 300,
              // itemHeight: 400,
              itemCount: 4,
              viewportFraction: 0.8,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  margin: EdgeInsets.all(30.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    image: DecorationImage(image: AssetImage(movies[index].image), fit: BoxFit.cover),
                    boxShadow: [
                      BoxShadow(
                        offset: Offset(0, 5.0),
                        blurRadius: 10.0,
                        spreadRadius: 5.0,
                        color: Colors.black.withOpacity(0.25),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
