// import 'package:flutter/material.dart';
// import '../model.dart';
// import '../details.dart';

// class MovieItem extends StatelessWidget {
//   final Movie movie;
//   final String mykey;
//   final String detailsTag;
//   final String name;

//   const MovieItem({
//     Key key,
//     this.movie,
//     this.mykey,
//     this.detailsTag,
//     this.name,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(20.0),
//         boxShadow: [BoxShadow(color: Colors.black12, spreadRadius: 0.1, blurRadius: 10, offset: Offset(0, 2))],
//       ),
//       child: Column(
//         children: <Widget>[
//           Hero(
//             tag: mykey,
//             child: Container(
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(20.0),
//                 color: Colors.green,
//                 image: DecorationImage(
//                   image: AssetImage(movie.image),
//                   fit: BoxFit.cover,
//                 ),
//               ),
//               width: double.infinity,
//               height: 250,
//             ),
//           ),
//           SizedBox(
//             height: 20,
//           ),
//           Hero(
//             tag: detailsTag,
//             child: Container(
//               height: 300,
//               padding: EdgeInsets.only(top: 30, left: 20, right: 20),
//               decoration: BoxDecoration(
//                 // color: Colors.blue,
//                 borderRadius: BorderRadius.circular(20.0),
//               ),
//               child: Material(
//                 color: Colors.transparent,
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: <Widget>[
//                     Text(
//                       movie.name,
//                       style: TextStyle(color: Colors.blueGrey[600], fontSize: 40.0),
//                     ),
//                     SizedBox(
//                       height: 10.0,
//                     ),
//                     Text(
//                       movie.geners.toString(),
//                       style: TextStyle(fontSize: 17.0),
//                     ),
//                     SizedBox(
//                       height: 15.0,
//                     ),
//                     Expanded(
//                       child: Text(
//                         movie.description,
//                         style: TextStyle(color: Colors.grey),
//                       ),
//                     ),
//                     Align(
//                       alignment: Alignment.bottomCenter,
//                       child: IconButton(
//                         icon: Icon(
//                           Icons.drag_handle,
//                           color: Colors.grey[400],
//                         ),
//                         onPressed: () {
//                           Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) {
//                             return Details(
//                               movie: movie,
//                               tag: mykey,
//                               detailsTag: detailsTag,
//                             );
//                           }));
//                         },
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
