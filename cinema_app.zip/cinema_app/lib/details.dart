import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'model.dart';

class Details extends StatefulWidget {
  // final Movie movie;
  // final String tag;
  // final String detailsTag;

  // const Details({Key key, this.movie, this.tag, this.detailsTag}) : super(key: key);

  @override
  DetailsState createState() {
    return new DetailsState();
  }
}

class DetailsState extends State<Details> {
  final movie = movies[2];
  VideoPlayerController _playerController;

  @override
  void initState() {
    super.initState();
    _playerController =
        VideoPlayerController.network("https://trailers.apple.com/movies/a24/moonlight/moonlight-trailer-1_h480p.mov")
          ..initialize().then((_) {
            setState(() {});
          });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   backgroundColor: Colors.transparent,
      //   elevation: 0.0,
      // ),
      body: Stack(
        children: <Widget>[
          Container(
            height: 240,
            color: Colors.red,
            child: VideoPlayer(_playerController),
          ),
          Container(
            margin: EdgeInsets.only(top: 220),
            height: MediaQuery.of(context).size.height - 220,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0),
              ),
              color: Colors.blue,
            ),
          ),
          Positioned(
            left: 20.0,
            top: 170,
            child: Container(
              width: 150,
              height: 200,
              decoration: BoxDecoration(
                image: DecorationImage(image: AssetImage(movie.image), fit: BoxFit.cover),
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
